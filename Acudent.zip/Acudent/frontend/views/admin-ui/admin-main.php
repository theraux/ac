<?php
require_once("../../../backend/middleware/auth-session-admin.php"); 
         ?> 
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="../../assets/css/admin-ui/admin-backup-css/admin-dashboard.css">
    <link rel="stylesheet" href="../../assets/css/admin-ui/admin-backup-css/admin-messages.css">
    <link rel="stylesheet" href="../../assets/css/admin-ui/admin-main.css">
    <link rel="stylesheet" href="../../assets/css/admin-ui/admin-backup-css/admin-shared-management-detailed.css">
    <link rel="stylesheet" href="../../assets/css/admin-ui/admin-backup-css/admin-record-management-shared.css">
    <link rel="stylesheet" href="../../assets/css/admin-ui/admin-backup-css/admin-inventory-management-new.css">
    <link rel="stylesheet" href="../../assets/css/admin-ui/admin-backup-css/admin-reports.css">
    <link rel="stylesheet" href="../../assets/css/admin-ui/admin-backup-css/admin-appointments.css">
    <link rel="stylesheet" href="../../assets/css/admin-ui/admin-backup-css/admin-services.css">
    <link rel="stylesheet" href="../../assets/css/admin-ui/admin-backup-css/admin-help.css">
    <link rel="stylesheet" href="../../assets/css/admin-ui/admin-backup-css/admin-shared-management-detailed.css">
    <link rel="stylesheet" href="../../assets/css/admin-ui/admin-backup-css/shared-printable-information-record.css">
    <link rel="stylesheet" href="../../assets/css/admin-ui/admin-backup-css/report-folder/admin-appointment-report.css">
    <link rel="stylesheet" href="../../assets/css/admin-ui/admin-backup-css/report-folder/admin-financial-report.css">
    <link rel="stylesheet" href="../../assets/css/admin-ui/admin-backup-css/report-folder/admin-inventory-report.css">
        <link rel="stylesheet" href="../../assets/css/admin-ui/admin-backup-css/clinic-staff-record-folder/add-clinic-dentist-record.css">

    <link rel="stylesheet" href="../../assets/css/admin-ui/admin-backup-css/shared-folder-add/add-new.css">
    <link rel="stylesheet" href="../../assets/css/shared-ui/shared.css">
    <link rel="stylesheet" href="../../assets/css/shared-ui/patient-management-folder/add-new-patient.css">




 
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href='https://cdn.boxicons.com/fonts/basic/boxicons.min.css' rel='stylesheet'>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap');
    </style>

    <title>Admin Portal</title>
</head>

<body>

    <!-- ============================Main Container============================ -->
    <div class="main-container container-fluid d-flex px-0">

        <!-- ============================Sidebar Container============================ -->
        <aside class="sidebar-container" id="sidebar-container">
            <!-- Logo -->
            <div class="sidebar-top-logo mx-3">
                <div class="toggle-sidebar">
                    <i class="fa-solid fa-bars"></i>
                </div>
                <img src="../../assets/images/user-interface/banners-images-logo/logo.png" alt="Clinic Logo"
                    class="logo-img">
                <div class="logo-text ms-2">
                    <h3 class="mb-0">Mapru</h3>
                    <h5 class="mb-0">Dental Clinic</h5>
                </div>
            </div>

            <div class="sidebar-content ps-2 pt-2">
                <nav class="sidebar-navigation w-100">
                    <ul class="sidebar-nav-list">

                        <li class="sidebar-section-title">Overview</li>
                        <li>
                            <a href="../admin-ui/admin-main.html#../admin-ui/admin-subfolder/admin-dashboard.html"
                                class="btn-sidebar d-flex align-items-center"
                                data-page="../admin-ui/admin-subfolder/admin-dashboard.html" title="Dashboard">
                                <i class="fa-solid fa-house"></i><span>Dashboard</span></a>
                        </li>

                        <li class="sidebar-section-title">Navigation</li>

                        <li><a href="../admin-ui/admin-main.html#../admin-ui/admin-subfolder/admin-appointments.html"
                                class="btn-sidebar d-flex align-items-center"
                                data-page="../admin-ui/admin-subfolder/admin-appointments.html">
                                <i class="fas fa-calendar"></i> <span>Appointments</span></a>
                        </li>

                        <li><a href="../admin-ui/admin-main.html#../admin-ui/admin-subfolder/admin-messages.html"
                                class="btn-sidebar d-flex align-items-center"
                                data-page="../admin-ui/admin-subfolder/admin-messages.html">
                                <i class="fa-solid fa-message"></i><span>Messages</span></a>
                        </li>

                        <li><a href="../admin-ui/admin-main.html#../admin-ui/admin-subfolder/admin-patient-management.html"
                                class="btn-sidebar d-flex align-items-center"
                                data-page="../admin-ui/admin-subfolder/admin-patient-management.html">
                                <i class="fa-solid fa-id-card-clip"></i> <span>Patient Management</span></a>
                        </li>

                        <li><a href="../admin-ui/admin-main.html#../admin-ui/admin-subfolder/admin-dentist-management.html"
                                class="btn-sidebar d-flex align-items-center"
                                data-page="../admin-ui/admin-subfolder/admin-dentist-management.html">
                                <i class="fa-solid fa-user-doctor"></i><span>Dentist Management</span></a>
                        </li>

                        <li><a href="../admin-ui/admin-main.html#../admin-ui/admin-subfolder/admin-staff-management.html"
                                class="btn-sidebar d-flex align-items-center"
                                data-page="../admin-ui/admin-subfolder/admin-staff-management.html">
                                <i class="fa-solid fa-user-nurse"></i><span>Staff Management</span></a>
                        </li>

                        <li><a href="../admin-ui/admin-main.html#../admin-ui/admin-subfolder/admin-inventory-management-new.html"
                                class="btn-sidebar d-flex align-items-center"
                                data-page="../admin-ui/admin-subfolder/admin-inventory-management-new.html">
                                <i class="fa-solid fa-toolbox"></i><span>Inventory Management</span></a>
                        </li>

                        <!-- Reports with dropdown -->
                        <li>
                            <!-- Main Reports button (clickable toggle) -->
                            <a class="btn-sidebar d-flex align-items-center" data-bs-toggle="collapse"
                                href="#reportsDropdown" role="button" aria-expanded="false"
                                aria-controls="reportsDropdown">
                                <i class="fas fa-book"></i>
                                <span>Reports</span>
                                <i class="fas fa-chevron-down ms-auto"></i> <!-- arrow icon on right -->
                            </a>

                            <!-- Dropdown list -->
                            <ul class="collapse ms-3 mt-2 list-unstyled" id="reportsDropdown">
                                <li>
                                    <a href="../admin-ui/admin-main.html#../admin-ui/admin-subfolder/report-folder/admin-financial-report.html"
                                        class="btn-sidebar d-flex align-items-center"
                                        data-page="../admin-ui/admin-subfolder/report-folder/admin-financial-report.html">
                                        <i class="fas fa-coins me-1"></i> <span>Financial Report</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="../admin-ui/admin-main.html#../admin-ui/admin-subfolder/report-folder/admin-inventory-report.html"
                                        class="btn-sidebar d-flex align-items-center"
                                        data-page="../admin-ui/admin-subfolder/report-folder/admin-inventory-report.html">
                                        <i class="fas fa-boxes me-1"></i> <span>Inventory Report</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="../admin-ui/admin-main.html#../admin-ui/admin-subfolder/report-folder/admin-appointment-report.html"
                                        class="btn-sidebar d-flex align-items-center"
                                        data-page="../admin-ui/admin-subfolder/report-folder/admin-appointment-report.html">
                                        <i class="fas fa-calendar-check me-1"></i> <span>Appointment Report</span>
                                    </a>
                                </li>

                            </ul>
                        </li>

                        <li><a href="../admin-ui/admin-main.html#../admin-ui/admin-subfolder/admin-services.html"
                                class="btn-sidebar d-flex align-items-center"
                                data-page="../admin-ui/admin-subfolder/admin-services.html">
                                <i class="fa-solid fa-screwdriver-wrench"></i> <span>Services</span></a>
                        </li>

                        <li class="sidebar-section-title">Components</li>
                        <li><a href="../admin-ui/admin-main.html#../admin-ui/admin-subfolder/admin-help.html"
                                class="btn-sidebar d-flex align-items-center"
                                data-page="../admin-ui/admin-subfolder/admin-help.html">
                                <i class="fa-solid fa-circle-question"></i> <span>Help</span></a>
                        </li>

                        <li><a href="../admin-ui/admin-main.html#../admin-ui/admin-subfolder/admin-security.html"
                                class="btn-sidebar d-flex align-items-center"
                                data-page="../admin-ui/admin-subfolder/admin-security.html">
                                <i class="fa-solid fa-lock"></i><span>Security</span></a>
                        </li>



                    </ul>
                </nav>

                <!-- Logout -->
                <div class="sidebar-logout pe-2">
                    <a href="#" class="btn-sidebar sidebar-logout-btn d-flex align-items-center" id="logoutBtn"
                        onclick="logout(); return false;">
                        <i class="fa-solid fa-right-from-bracket"></i> <span>Logout</span>
                    </a>
                </div>
            </div>
        </aside>

        <!-- ============================Content Area Container============================ -->
        <main class="main-content-area-container" id="user-patient-content-area">
            <div class="topbar" id="user-patient-topbar">
                <div class="topbar-left">
                    <div class="toggle">
                        <i class="fa-solid fa-bars"></i>
                    </div>
                    <h3>Today's Date:</h3>
                    <div class="today-date" id="today-date"></div>
                </div>

                <div class="contentarea-topbar-profile">
                    <div class="notification">
                        <a href="#" class="icon-wrapper me-3 position-relative" title="Messages">
                            <i class="fa-solid fa-envelope"></i>
                            <span class="badge message-badge">1</span>
                        </a>

                        <a href="#" class="icon-wrapper icon-bell-notif me-5 position-relative" title="Notifications">
                            <i class="fas fa-bell"></i>
                            <span class="badge system-notif-badge">1</span>
                        </a>
                    </div>
                    <h4 class="topbar-profile-name" id="user-patient-profilename">

                    </h4>
                    <div class="contentarea-topbar-user">
                        <img src="../../assets/images/user-interface/banners-images-logo/profile-placeholder.png"
                            alt="Admin Profile">
                    </div>
                </div>
            </div>

            <div class="content-container d-flex flex-column">
                <div class="content-area  flex-grow-1" id="content-area"></div>

                <footer class="footer w-100 d-flex justify-content-end align-items-center p-3">
                    <div class="footer-inner w-100 d-flex justify-content-end align-items-center">
                        <p class="m-0">&copy; 2025 Mapru</p>
                    </div>
                </footer>
            </div>


        </main>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../../assets/js/shared-ui/shared.js"></script>
    <script src="../../assets/js/admin-ui/admin-main.js"></script>
    <script src="../../assets/js-api/admin-api/admin-main.api.js"></script>
    <script src="/Acudent/frontend/assets/js-api/auth/protected-pages.js"></script>

    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

</body>

</html>