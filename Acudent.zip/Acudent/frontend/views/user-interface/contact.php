<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MAPRU - Contact</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../../assets/css/user-interface/contact.css">
    <link rel="stylesheet" href="../../assets/css/user-interface/navbar.css">
    <link rel="stylesheet" href="../../assets/css/user-interface/footer.css">
    <link rel="stylesheet" href="../../assets/css/user-interface/reusable-component/global.css">

    <link rel="stylesheet" href="../../assets/css/user-interface/reusable-component/global.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Pacifico&display=swap');
    </style>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap');
    </style>

</head>

<body>

    <div class="main-container overflow-hidden">

        <?php include '../user-interface/navbar.php'; ?>


        <div class="landing-page-content-main-container">
            <!----------Landing Page --------------->


            <!-- ========================== Section 1 ============================== -->

            <section class="section1 d-flex flex-column justify-content-center align-items-center">

                <div class="dentists-hero-banner w-100 ">
                    <div
                        class="dentists-hero-banner-inner d-flex flex-column justify-content-center align-items-center">
                        <div class="dentists-hero-banner-title">
                            <h1>Interact With Us</h1>
                        </div>
                        <hr class="hori-line">
                        <div
                            class="dentists-hero-banner-sub mt-4 d-flex flex-row w-100 justify-content-center align-items-center gap-3">
                            <div class="dentists-hero-banner-sub-left d-flex flex-row">
                                <h5> <a href="../user-interface/index.php"><i
                                            class="fa-solid fa-house me-2"></i>Home</a> <i
                                        class="fa-solid fa-chevron-right mx-3"></i></h5>


                            </div>
                            <div class="dentists-hero-banner-sub-right">
                                <h5>Contact</h5>

                            </div>
                        </div>
                    </div>
                </div>
            </section>


            <!-- ========================== Section 3 ================================ -->

            <section class="section2">
                <div class="contact-us-secondbanner-container">
                    <div class="contact-us-banner2-inner py-4">

                   
                    <div class="row row-cols-xxl-2 row-cols-xl-2 row-cols-lg-1 row-cols-md-1 row-cols-sm-1 row-cols-1">
                        <div class="col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12 reveal reveal-left">
                            <div class="contact-us-secondbanner-img-container">
                       <img src="../../assets/images/user-interface/doctors/mapru-contact.jpg"
                                            alt="Contact Us Photo">
                    </div>
                        </div>
                        <div class="col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12 reveal reveal-right">
                            <div class="contact-us-secondbanner-text">
                                <h3><i class="fa-solid fa-hand-pointer"></i> Get in touch</h3>
                                <h5>Care That Begins Before Your Visit</h5>
                                <div class="contact-us-secondbanner-inner-text ">
                                    <p>Whether you have a question, concern, or are ready to book an appointment, the
                                        MAPRU
                                        Dental Clinic team is always happy to hear from you. We believe that open
                                        communication
                                        is the first step to comfortable and confident dental care. Feel free to call,
                                        message,
                                        or send us an inquiry—no concern is too small. Our friendly staff will gladly
                                        assist
                                        you, guide you through your options, and help you feel at ease even before you
                                        step into
                                        our clinic.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                 </div>



            </section>

            <!-- =================================== Section 3 & 7 =================================== -->

            <?php include '../user-interface/reusable-component/contact-component.php'; ?>



            <!-- ============================= Section 4 ================================ -->

            <section class="section4">
                
                <div class="row row-cols-xxl-2 row-col-xl-2 row-cols-lg-1 row-cols-md-1 row-cols-sm-1 row-cols-1">
                    <div class="col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12 reveal reveal-left">
                        <div class="contact-us-review-left-container w-100 ">
                            <div class="contact-us-review-img-wrapper">
                                <img src="../../assets/images/user-interface/doctors/mapru-contact-us.jpg"
                                            alt="Contact Us Photo">
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12 reveal reveal-right">
                        <div class="contact-us-review-right-container w-100 h-100 d-flex flex-column align-items-center justify-content-center">
                            <div class="contact-us-review-clients">
                                <h5><i class="fa-solid fa-hand-holding-heart"></i> Comfort Comes First</h5>
                                <h4>Dental Care Designed to Help You Feel at Ease</h4>
                                <p>A calm, supportive environment where your concerns are always understood.</p>
                            </div>

                            <div class="contact-us-reviews-wrapper" id="contact-us-reviews-wrapper-id">

                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- ================================= Section 5 =============================== -->

            <section class="section5">
                <div class="contact-us-location-container">
                    <div class="contact-us-location-title">
                        <h5 class="reveal reveal-header"><i class="fa-solid fa-location-dot me-2"></i>Visit Us</h5>
                        <h3 class="reveal reveal-header">Where to find Mapru Dental Clinic</h3>
                        <p class="reveal reveal-header">Come in and experience personalized dental care in a comfortable, welcoming space.</p>
                    </div>

                    <div class="row row-cols-xxl-2 row-cols-xl-2 row-cols-lg-1 row-cols-md-1 row-cols-sm-1 row-cols-1">
                        <div class="col-xxl-5 col-xl-5 col-lg-12 col-md-12 col-sm-12 col-12 reveal reveal-left">
                            <div class="contact-us-secondbanner-wrapper-left">
                                <div class="contact-us-secondbanner-text-left py-5">
                                    <h3>Mapru Dental Clinic</h3>
                                    <p>We are near at King James Academy Cavite, inc.</p>
                                    <div class="contact-us-secondbanner-inner-left py-3">
                                        <h5>Location</h5>
                                        <p><i class="fa-solid fa-location-dot me-2"></i> 9067 DSM Subdivision Mambog 1,
                                            Bacoor City, Cavite</p>

                                        <p><i class="fa-solid fa-phone me-2"></i> 0915 748 5132
                                        <p>
                                            <hr class="hori-line">
                                        <h5>Store Open</h5>
                                        <p><i class="fa-solid fa-calendar-day me-2"></i> Monday - Sunday</p>

                                        <p><i class="fa-solid fa-clock me-2"></i> 10:00 AM - 5:00 PM</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xxl-7 col-xl-7 col-lg-12 col-md-12 col-sm-12 col-12 reveal reveal-right">
                            <div class="contact-us-map ">
                                <iframe
                                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3864.073138365199!2d120.94744627579509!3d14.42294728604263!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397d25b9c7a8d79%3A0xf33a33d44be4864!2sMAPRU%20Dental%20Clinic!5e0!3m2!1sen!2sph!4v1766144786114!5m2!1sen!2sph"
                                    style="border:0;" allowfullscreen="" loading="lazy"
                                    referrerpolicy="no-referrer-when-downgrade"></iframe>
                            </div>
                        </div>
                    </div>
                </div>
            </section>



            <!-- =================== Section 6.5 - FAQ ======================= -->

            <section class="section6">
                <div class="faq-main-container">
                    <div class="faq-main-container-inner">
                        <div class="row row-cols-2">
                            <div class="col col-5  reveal reveal-left">
                                <div class="faq-col-left">
                                    <div class="faq-col-left-inner w-100">
                                        <div class="faq-header">
                                            <h5><i class="fa-regular fa-circle-question ms-1"></i> Frequently Asked
                                                Questions</h5>
                                            <h2>Everything</h2>
                                            <h2 class="mb-4">You Need to Know</h2>
                                            <p class="faq-description">
                                                Find clear answers to the most common questions about our dental
                                                services, treatments, and patient care. We’re here to help you feel
                                                confident and informed before your visit.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col col-7  reveal reveal-right">
                                <div class="faq-col-right">
                                    <div class="faq-col-right-inner">
                                        <div class="faq-content">
                                            <div class="faq-list">
                                                <div class="faq-item">
                                                    <div class="faq-question">
                                                        <button>How to get there from SM Bacoor?</button>
                                                        <div class="faq-questionn-icon">
                                                            <i class="fa-solid fa-angle-down"></i>
                                                        </div>
                                                    </div>
                                                    <div class="faq-answer">
                                                        <p>From SM Bacoor, ride a jeep with a sign of SM Molino then
                                                            drop off at Alfamart palico IV Imus,
                                                            then ride a trycicle to a diamond street near the King James
                                                            Academy.
                                                        </p>

                                                        <div class="faq-note">
                                                            <p>Note: There is only a limited parking</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="faq-item">
                                                    <div class="faq-question">
                                                        <button>How to get there from Lumina Mall?</button>
                                                        <div class="faq-questionn-icon">
                                                            <i class="fa-solid fa-angle-down"></i>
                                                        </div>
                                                    </div>
                                                    <div class="faq-answer">
                                                        <p>From Lumina Mall, ride a green cab with a sign of SM Molino
                                                            then drop off at Alfamart palico IV Imus,
                                                            then ride a trycicle to a diamond street near the King James
                                                            Academy.</p>

                                                        <div class="faq-note">
                                                            <p>Note: There is only a limited parking</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="faq-item">
                                                    <div class="faq-question">
                                                        <button>How to get there from Nomo?</button>
                                                        <div class="faq-questionn-icon">
                                                            <i class="fa-solid fa-angle-down"></i>
                                                        </div>
                                                    </div>
                                                    <div class="faq-answer">
                                                        <p>From Nomo, ride a jeep with a sign of SM Bacoor then drop off
                                                            at Alfamart palico IV Imus,
                                                            then ride a trycicle to a diamond street near the King James
                                                            Academy.</p>
                                                        <div class="faq-note">
                                                            <p>Note: There is only a limited parking</p>
                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="faq-item">
                                                    <div class="faq-question">
                                                        <button>How to get there from SM Molino?</button>
                                                        <div class="faq-questionn-icon">
                                                            <i class="fa-solid fa-angle-down"></i>
                                                        </div>
                                                    </div>
                                                    <div class="faq-answer">
                                                        <p>From SM molino, ride a jeep with a sign of Imus then drop off
                                                            at 7/11 Mambog,
                                                            then walk then you will see King James Academy.</p>

                                                        <div class="faq-note">
                                                            <p>Note: There is only a limited parking</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="faq-item">
                                                    <div class="faq-question">
                                                        <button>How to get there from SM Dasma?</button>
                                                        <div class="faq-questionn-icon">
                                                            <i class="fa-solid fa-angle-down"></i>
                                                        </div>
                                                    </div>
                                                    <div class="faq-answer">
                                                        <p>From SM Dasma, ride a jeep with a sign of SM Molino then drop
                                                            off at Alfamart palico IV Imus,
                                                            then ride a trycicle to a diamond street near the King James
                                                            Academy.</p>

                                                        <div class="faq-note">
                                                            <p>Note: There is only a limited parking</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>


            <!-- ============================== Section 7.5 ============================== -->

            <section class="section75">
                <div class="section5-inner d-flex flex-column justify-content-end align-items-center">

                    <div class="col-left-book-now text-center">
                        <h2 class="reveal reveal-header">
                            Ready to Book Your Appointment?
                        </h2 class="reveal reveal-header">
                        <p class="reveal reveal-header">
                            Contact us today to schedule your visit and take the first step toward a healthier smile.
                        </p>
                    </div>

                    <div class="col-right-book-now reveal reveal-content">
                        <div class="col-right-book-now-btn h-100 ">
                            <button class="book-now-btn">
                                Book Appointment
                            </button>
                        </div>
                    </div>

                </div>

            </section>

            <!-- =================== Footer ========================= -->

            <?php include '../user-interface/footer.php'; ?>

        </div>





        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="../../assets/js/user-interface/navbar.js"></script>
        <script src="../../assets/js/user-interface/footer.js"></script>
        <script src="../../assets/js/user-interface/contact.js"></script>



</body>

</html>