<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../../assets/css/user-interface/services.css">
    <link rel="stylesheet" href="../../assets/css/user-interface/auth.css">
    <link rel="stylesheet" href="../../assets/css/user-interface/footer.css">
    <link rel="stylesheet" href="../../assets/css/user-interface/navbar.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    
    <style>
@import url('https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap');
</style>

    <title>MAPRU - Services</title>
</head>
<body>
   
   <?php include '../user-interface/navbar.php'; ?>

   <?php include '../../PHP/user-interface/auth.php'; ?>
  <!-- ======================================================================================================================================= -->


  <!--Sign In Popup Modal-->
  <div id="authentication-modal-container"></div>
  <script src="../../assets/js/user-interface/auth-loader.js"></script>


  <!--Sign In Popup Modal-->

  <!-- ======================================================================================================================================= -->




    <div class="banner">
        <img src="../../assets/images/user-interface/banners-images-logo/mapru_servicescopy.jpg" alt="Banner 3">
        <div class="bottom-left-container">
        <div class ="bottom-left">Expert dental services <br> for a healthier smile</div>
        <button id="Appointment">Schedule an Appointment</button>
        </div>
    </div>


    <!---->
 <div class="after-banner">
    <h2>Our Expertise</h2>
    <p>We provide expert dental care to keep your smile healthy and bright</p>
 </div>

   <section class="service-section" id="periodontics">
  <p>Periodontics</p>
  <div class="service-row">
    <div class="service">
      <img src="../../assets/images/user-interface/services/prophylaxis.png" alt="Oral Prophylaxis">
      <div class="title">Oral Prophylaxis</div>
    </div>
    <div class="service">
      <img src="../../assets/images/user-interface/services/scaling.png" alt="Deep Scaling">
      <div class="title">Deep Scaling</div>
    </div>
  </div>
</section>

<section class="service-section" id="cosmetic-care">
  <p>Cosmetic Care</p>
  <div class="service-row">
    <div class="service">
      <img src="../../assets/images/user-interface/services/esthetic.png" alt="Tooth Filling">
      <div class="title">Tooth Filling</div>
    </div>
    <div class="service">
      <img src="../../assets/images/user-interface/services/Orthodontics.png" alt="Teeth Whitening">
      <div class="title">Teeth Whitening</div>
    </div>
    <div class="service">
      <img src="../../assets/images/user-interface/services/bond.png" alt="Cosmetic Bonding">
      <div class="title">Cosmetic Bonding</div>
    </div>
  </div>
</section>

<section class="service-section" id="orthodontics">
  <p>Orthodontics</p>
  <div class="service-row">
    <div class="service">
      <img src="../../assets/images/user-interface/services/metal.png" alt="Metal Braces">
      <div class="title">Metal Braces</div>
    </div>
    <div class="service">
      <img src="../../assets/images/user-interface/services/ceramic.png" alt="Ceramic Braces">
      <div class="title">Ceramic Braces</div>
    </div>
    <div class="service">
      <img src="../../assets/images/user-interface/services/self-ligating.png" alt="Self-Ligating Braces">
      <div class="title">Self-Ligating Braces</div>
    </div>
  </div>
</section>

<section class="service-section" id="prosthodontics">
  <p>Prosthodontics</p>
  <div class="service-row">
    <div class="service">
      <img src="../../assets/images/user-interface/services/fixed.png" alt="Fixed Denture">
      <div class="title">Fixed Denture</div>
    </div>
    <div class="service">
      <img src="../../assets/images/user-interface/services/partial.png" alt="Partial Denture">
      <div class="title">Partial Denture</div>
    </div>
    <div class="service">
      <img src="../../assets/images/user-interface/services/completed.png" alt="Complete Dentures">
      <div class="title">Complete Dentures</div>
    </div>
  </div>
</section>

<section class="service-section" id="surgical-treatment">
  <p>Surgical Treatment</p>
  <div class="service-row">
    <div class="service">
      <img src="../../assets/images/user-interface/services/Implant.png" alt="Implant">
      <div class="title">Implant</div>
    </div>
    <div class="service">
      <img src="../../assets/images/user-interface/services/Surgery.png" alt="Surgery">
      <div class="title">Surgery</div>
    </div>
  </div>
</section>


    <!--Footer Section-->
    <div id="footer"></div>
    <script src="../../assets/js/user-interface/footer.js"></script>
    <script src="../../assets/js/user-interface/navbar.js"></script>
    <!--Footer Section-->

      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>


</body>
</html>