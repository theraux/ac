document.addEventListener("DOMContentLoaded", () => {
    const signUpForm = document.querySelector("#signUp form");
    if (!signUpForm) return;

    // Get all form elements
    const firstNameInput = document.getElementById("first-name");
    const lastNameInput = document.getElementById("last-name");
    const emailInput = document.querySelector("#signUp #email");
    const passwordInput = document.querySelector("#signUp #password");
    const confirmPasswordInput = document.getElementById("confirm-password");
    const termsCheckbox = document.getElementById("TermsAndCondtionSignUp");
    const submitButton = signUpForm.querySelector(".sign-up-button button");

    // Create error message container if it doesn't exist
    let errorContainer = signUpForm.querySelector(".signup-error-msg");
    if (!errorContainer) {
        errorContainer = document.createElement("div");
        errorContainer.className = "signup-error-msg";
        errorContainer.style.cssText = "color: red; margin: 15px 0; padding: 10px; border-radius: 5px; background-color: #ffe6e6; display: none;";
        signUpForm.querySelector(".sign-up-container-form").prepend(errorContainer);
    }

    // Create success message container
    let successContainer = signUpForm.querySelector(".signup-success-msg");
    if (!successContainer) {
        successContainer = document.createElement("div");
        successContainer.className = "signup-success-msg";
        successContainer.style.cssText = "color: green; margin: 15px 0; padding: 10px; border-radius: 5px; background-color: #e6ffe6; display: none;";
        signUpForm.querySelector(".sign-up-container-form").prepend(successContainer);
    }

    // Client-side validation
    function validateForm() {
        const errors = [];

        // Check required fields
        if (!firstNameInput.value.trim()) errors.push("First name is required");
        if (!lastNameInput.value.trim()) errors.push("Last name is required");
        if (!emailInput.value.trim()) errors.push("Email is required");
        if (!passwordInput.value) errors.push("Password is required");
        if (!confirmPasswordInput.value) errors.push("Confirm password is required");

        // Email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (emailInput.value && !emailRegex.test(emailInput.value)) {
            errors.push("Invalid email format");
        }

        // Password validation
        if (passwordInput.value) {
            if (passwordInput.value.length < 8) {
                errors.push("Password must be at least 8 characters");
            }
            if (!/\d/.test(passwordInput.value)) {
                errors.push("Password must contain at least one number");
            }
            if (!/[^A-Za-z0-9]/.test(passwordInput.value)) {
                errors.push("Password must contain at least one special character");
            }
        }

        // Password match
        if (passwordInput.value !== confirmPasswordInput.value) {
            errors.push("Passwords do not match");
        }

        // Terms and conditions
        if (!termsCheckbox.checked) {
            errors.push("You must agree to the Terms and Conditions");
        }

        return errors;
    }

    // Display errors
    function showErrors(errors) {
        if (errors.length === 0) {
            errorContainer.style.display = "none";
            return;
        }

        let errorHTML = "<strong>Please fix the following errors:</strong><ul style='margin: 5px 0 0 20px;'>";
        errors.forEach(error => {
            errorHTML += `<li>${error}</li>`;
        });
        errorHTML += "</ul>";

        errorContainer.innerHTML = errorHTML;
        errorContainer.style.display = "block";
        successContainer.style.display = "none";

        // Scroll to error
        errorContainer.scrollIntoView({ behavior: "smooth", block: "center" });
    }

    // Show success message
    function showSuccess(message) {
        successContainer.textContent = message;
        successContainer.style.display = "block";
        errorContainer.style.display = "none";
    }

    // Handle form submission
    signUpForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        // Validate form
        const errors = validateForm();
        if (errors.length > 0) {
            showErrors(errors);
            return;
        }

        // Disable submit button
        submitButton.disabled = true;
        submitButton.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Creating Account...';

        try {
            const response = await fetch("/Acudent/backend/api/auth/auth-signup.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    first_name: firstNameInput.value.trim(),
                    last_name: lastNameInput.value.trim(),
                    email: emailInput.value.trim(),
                    password: passwordInput.value,
                    confirm_password: confirmPasswordInput.value
                })
            });

            // Check if response is ok
            if (!response.ok) {
                console.error("HTTP Error:", response.status, response.statusText);
                throw new Error(`Server returned ${response.status}`);
            }

            const result = await response.json();
            console.log("Server response:", result);

            if (!result.success) {
                // Show server errors
                if (result.errors && Array.isArray(result.errors)) {
                    showErrors(result.errors);
                } else {
                    showErrors([result.message || "Registration failed"]);
                }
                
                // Re-enable button
                submitButton.disabled = false;
                submitButton.innerHTML = '<i class="fa-solid fa-right-to-bracket"></i> Sign Up';
                return;
            }

            // Success - store token and redirect
            showSuccess(result.message || "Account created successfully! Redirecting...");

            if (result.token) {
                localStorage.setItem("authToken", result.token);
            }

            // Redirect after 1.5 seconds
            setTimeout(() => {
                window.location.href = result.redirect || "../patient-ui/patient-main.php";
            }, 1500);

        } catch (error) {
            console.error("Sign-up error:", error);
            showErrors(["Error connecting to server. Please try again."]);
            
            // Re-enable button
            submitButton.disabled = false;
            submitButton.innerHTML = '<i class="fa-solid fa-right-to-bracket"></i> Sign Up';
        }
    });

    // Real-time password validation feedback (optional enhancement)
    passwordInput.addEventListener("input", () => {
        // This is already handled by your existing authentication.js
        // Just ensure validation on submit
    });

    confirmPasswordInput.addEventListener("input", () => {
        // This is already handled by your existing authentication.js
        // Just ensure validation on submit
    });
});