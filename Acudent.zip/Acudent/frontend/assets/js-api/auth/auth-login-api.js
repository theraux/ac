document.addEventListener("DOMContentLoaded", () => {
    const loginForm = document.querySelector("#adminLoginForm"); // Select the form inside signIn
    if (!loginForm) return;

    loginForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const email = document.getElementById("login-email").value.trim();
const password = document.getElementById("login-password").value.trim();

        // Create error message element if it doesn't exist
        let errorMsg = document.querySelector(".error-msg");
        if (!errorMsg) {
            errorMsg = document.createElement("div");
            errorMsg.className = "error-msg";
            errorMsg.style.color = "red";
            errorMsg.style.marginTop = "10px";
            loginForm.querySelector(".log-in-container").prepend(errorMsg);
        }

        if (!email || !password) {
            errorMsg.textContent = "Please enter email and password.";
            return;
        }

        try {
            const response = await fetch("/Acudent/backend/api/auth/auth-login.php", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ email, password })
            });

            const result = await response.json();

            if (!result.success) {
                errorMsg.textContent = result.message || "Invalid login.";
                return;
            }

            if (result.token) {
                localStorage.setItem("authToken", result.token);
            }

            window.location.href = result.redirect;

        } catch (err) {
            console.error(err);
            errorMsg.textContent = "Error connecting to server.";
        }
    });
});