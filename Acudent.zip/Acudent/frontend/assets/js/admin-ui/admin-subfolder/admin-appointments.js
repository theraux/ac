function initAdminAppointments() {
    initCalendar();
    AppointmentTable();
    initWorkingHours();


}


// =================== Appointment Header Table ============================

function AppointmentTable(){
    const tbody = document.getElementById('today-appointment-body-id');
    tbody.innerHTML = '';
    const Appointments = [
        {
            name: 'John Doe',
            type: 'Checkup',
            time: '10:00 AM',
            dentist: 'Dr. Smith',
            status: 'confirmed'
        },
        {
            name: 'Jane Smith',
            type: 'Cleaning',
            time: '11:00 AM',
            dentist: 'Dr. Lee',
            status: 'cancelled'
        },
        {
            name: 'Bob Johnson',
            type: 'Filling',
            time: '12:00 PM',
            dentist: 'Dr. Kim',
            status: 'pending'
        },
        {
            name: 'Alice Brown',
            type: 'Consultation',
            time: '1:00 PM',
            dentist: 'Dr. Patel',
            status: 'confirmed'
        },
        {
            name: 'Charlie Wilson',
            type: 'Surgery',
            time: '2:00 PM',
            dentist: 'Dr. Gupta',
            status: 'cancelled'
        }
    ];


    Appointments.forEach(appointment => {
        const row = document.createElement('tr');

        let statusClass = '';
        if (appointment.status.toLowerCase() === 'confirmed') {
            statusClass = 'status-confirmed';
        } else if (appointment.status.toLowerCase() === 'cancelled') {
            statusClass = 'status-cancelled';
        } else {
            statusClass = 'status-default';
        }

        row.innerHTML = `
            <td>${appointment.name}</td>
            <td>${appointment.type}</td>
            <td>${appointment.time}</td>
            <td>${appointment.dentist}</td>
            <td class="${statusClass}">${appointment.status}</td>
        `;
        tbody.appendChild(row);

        const statusTd = row.querySelector('td:last-child');
        statusTd.innerHTML = `<span class="status-badge ${statusClass}">${appointment.status}</span>`;
        const badge = statusTd.querySelector('.status-badge');

    });

}


// =================== Calendar UI ===================
function initCalendar() {
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August',
        'September', 'October', 'November', 'December'];
    let currentDate = new Date();
    const today = new Date();
    let datePickingMode = false;
    let selectedDate = null;
    let appointmentMode = null;  
    

    const appointments = [];
    
    function renderDentistCalendar() {
        let year = currentDate.getFullYear();
        let month = currentDate.getMonth();
      
        document.getElementById('months-display').innerText = months[month] + ' ' + year;
    
        let firstDayOfWeek = new Date(year, month, 1).getDay();  
        let daysInMonth = new Date(year, month + 1, 0).getDate();
        let daysInPrevMonth = new Date(year, month, 0).getDate();
    
        let daysContainer = document.querySelector('.calendar-days-number-container');
        daysContainer.innerHTML = ''; 
    
        let nextDayCounter = 1;
    
        // Calendar
        for (let cellIndex = 0; cellIndex < 42; cellIndex++) {
            let dayDiv = document.createElement('div');
            dayDiv.className = 'calendar-days-number';
    
            if (cellIndex < firstDayOfWeek) {
                let prevDay = daysInPrevMonth - (firstDayOfWeek - 1 - cellIndex);
                dayDiv.innerHTML = `${prevDay}<br><small>Prev month</small>`;
                dayDiv.classList.add('prev-month');
            } else if (cellIndex < firstDayOfWeek + daysInMonth) {
                let day = cellIndex - firstDayOfWeek + 1;
                dayDiv.dataset.day = day;
                dayDiv.innerHTML = `${day}<br>`;

                const dayDateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                const dayAppointments = appointments.filter(app => app.date === dayDateStr);
                
                if (dayAppointments.length > 0) {
                    dayAppointments.forEach(app => {
                        const appDiv = document.createElement('div');
                        appDiv.className = 'calendar-appointment-item';
                        appDiv.innerHTML = `<small>${app.patient} - ${app.time} (${app.service})</small>`;
                        dayDiv.appendChild(appDiv);
                    });
                } else {
                    const noAppDiv = document.createElement('div');
                    noAppDiv.className = 'no-appointments';
                    noAppDiv.innerHTML = '<small>No appointments</small>';
                    dayDiv.appendChild(noAppDiv);
                }
                
                dayDiv.classList.add('current-month');
                                if (day === today.getDate() && month === today.getMonth() && year === today.getFullYear()) {
                    dayDiv.classList.add('today');
                }
    
                dayDiv.addEventListener('click', () => {
                    console.log('Calendar clicked, datePickingMode:', datePickingMode, 'appointmentMode:', appointmentMode, 'appointments:', dayAppointments.length); // Debug
                    if (datePickingMode) {
                        selectedDate = new Date(year, month, day);
                        if (appointmentMode === 'add') {
                            openDentistAppointmentModal(selectedDate);
                        } else if (appointmentMode === 'edit') {
                            openDentistEditModal(selectedDate);
                        }
                        datePickingMode = false;  
                        appointmentMode = null;  
                    } else {
                        if (dayAppointments.length > 0) {
                            openDentistViewModal(new Date(year, month, day), dayAppointments);
                        }
                    }
                });
            } else {
                dayDiv.innerHTML = `${nextDayCounter}<br><small>Next month</small>`;
                dayDiv.classList.add('next-month');
                nextDayCounter++;
            }
    
            daysContainer.appendChild(dayDiv);
        }
    }
    
    function Dentistprevmonth() {
        currentDate.setMonth(currentDate.getMonth() - 1);
        renderDentistCalendar();
    }
    
    function Dentistnextmonth() {
        currentDate.setMonth(currentDate.getMonth() + 1);
        renderDentistCalendar();
    }
    
    function goToToday() {
        currentDate = new Date();
        renderDentistCalendar();
    }
    
    document.getElementById('prev-month-btn-id').addEventListener('click', Dentistprevmonth);
    document.getElementById('next-month-btn-id').addEventListener('click', Dentistnextmonth);
    document.querySelector('.todays-date-btn').addEventListener('click', goToToday);
    
    renderDentistCalendar();
}






// ================= Side Panel Working Hours ===================
// ================= Side Panel Working Hours ===================
function initWorkingHours() {
    // Global variables to track selected times (in minutes for easy comparison)
    let selectedStart = null; // Selected start time in minutes (e.g., 9*60 + 30 = 570 for 9:30 AM)
    let selectedEnd = null;   // Selected end time in minutes

    function WorkingHours() {
        // Array of unique display IDs (must match the order of the dropdowns in the HTML)
        const displayIds = ["time-display-start", "time-display-end"];

        // Get all custom-select elements (for multiple dropdowns)
        const selects = document.querySelectorAll(".custom-select");

        selects.forEach((select, index) => {
            const timeOptions = select.querySelector(".custom-options"); // Use relative query for this select
            const display = select.querySelector("#" + displayIds[index]); // Select the correct display span using the unique ID
            const trigger = select.querySelector(".custom-select-trigger");

            // Start and end times (in minutes) - adjusted for start dropdown to end at 4:45 PM
            const startMinutes = 9 * 60;  // 9:00 AM
            let endMinutes = 17 * 60;     // 5:00 PM (default for end dropdown)
            if (index === 0) {            // For start dropdown, end at 4:45 PM
                endMinutes = 16 * 60 + 45; // 4:45 PM
            }
            const interval = 15;          // 15-minute intervals

            // Clear existing options before regenerating
            timeOptions.innerHTML = '';

            // Determine the actual start time for generation
            let actualStartMinutes = startMinutes;
            if (index === 1 && selectedStart !== null) { // For end dropdown, start from selectedStart + interval
                actualStartMinutes = selectedStart + interval;
            }

            // Generate options only if conditions are met
            if (index === 0 || (index === 1 && selectedStart !== null)) {
                for (let mins = actualStartMinutes; mins <= endMinutes; mins += interval) {
                    const hours = Math.floor(mins / 60);
                    const minutes = mins % 60;

                    // Format 12-hour time
                    const period = hours >= 12 ? "PM" : "AM";
                    const displayHour = ((hours + 11) % 12 + 1); // converts 13 -> 1, 0 -> 12
                    const displayMinute = minutes.toString().padStart(2, "0");

                    const displayTime = `${displayHour}:${displayMinute} ${period}`;
                    const valueTime = `${displayHour.toString().padStart(2, "0")}:${displayMinute} ${period}`;

                    // Create <li> element
                    const li = document.createElement("li");
                    li.className = "custom-option";
                    li.dataset.value = mins; // Store minutes for comparison
                    li.textContent = displayTime;

                    timeOptions.appendChild(li);
                }
            }

            // Get options for this select
            const options = select.querySelectorAll(".custom-option");

            // Toggle open/close on click - SKIP for end dropdown (attached separately below)
            if (index === 0) { // Only for start dropdown
                trigger.addEventListener("click", (e) => {
                    e.stopPropagation();
                    select.classList.toggle("open");
                });
            }

            // Click an option to select
            options.forEach(option => {
                option.addEventListener("click", () => {
                    const selectedMinutes = parseInt(option.dataset.value);
                    display.textContent = option.textContent;
                    select.classList.remove("open");

                    if (index === 0) { // Start time selected
                        selectedStart = selectedMinutes;
                        // Regenerate end dropdown options
                        regenerateEndDropdown();
                        // Check and clear end if invalid
                        if (selectedEnd !== null && selectedStart >= selectedEnd) {
                            selectedEnd = null;
                            document.querySelector("#time-display-end").textContent = "Select Time";
                        }
                    } else if (index === 1) { // End time selected
                        selectedEnd = selectedMinutes;
                    }
                });
            });

            // Close dropdown when clicking outside (global, but checks per select)
            document.addEventListener("click", (e) => {
                if (!select.contains(e.target)) {
                    select.classList.remove("open");
                }
            });
        });

        // Attach end dropdown trigger listener once (after the loop) - conditional and dynamic
        const endTrigger = document.querySelector("#time-trigger-end");
        endTrigger.addEventListener("click", (e) => {
            e.stopPropagation();
            if (selectedStart === null) {
                showToast("Select the start time first.");
                return;
            }
            document.querySelector("#time-select-end").classList.toggle("open");
        });

        // Helper function to regenerate end dropdown options after start selection
        function regenerateEndDropdown() {
            const endSelect = document.querySelector("#time-select-end");
            const endOptions = endSelect.querySelector(".custom-options");
            endOptions.innerHTML = ''; // Clear existing

            const startMinutes = 9 * 60; // Not used here, but for reference
            const endMinutes = 17 * 60; // 5:00 PM
            const interval = 15;

            const actualStartMinutes = selectedStart + interval; // Start from next interval after selectedStart

            for (let mins = actualStartMinutes; mins <= endMinutes; mins += interval) {
                const hours = Math.floor(mins / 60);
                const minutes = mins % 60;

                const period = hours >= 12 ? "PM" : "AM";
                const displayHour = ((hours + 11) % 12 + 1);
                const displayMinute = minutes.toString().padStart(2, "0");

                const displayTime = `${displayHour}:${displayMinute} ${period}`;

                const li = document.createElement("li");
                li.className = "custom-option";
                li.dataset.value = mins;
                li.textContent = displayTime;

                endOptions.appendChild(li);
            }

            // Re-attach event listeners for new options
            const newOptions = endSelect.querySelectorAll(".custom-option");
            const endDisplay = endSelect.querySelector("#time-display-end");

            newOptions.forEach(option => {
                option.addEventListener("click", () => {
                    const selectedMinutes = parseInt(option.dataset.value);
                    endDisplay.textContent = option.textContent;
                    endSelect.classList.remove("open");
                    selectedEnd = selectedMinutes;
                });
            });
        }

        // Simple toast function
        function showToast(message) {
            // Create toast element if it doesn't exist
            let toast = document.querySelector("#custom-toast");
            if (!toast) {
                toast = document.createElement("div");
                toast.id = "custom-toast";
                toast.style.position = "fixed";
                toast.style.top = "40px";
                toast.style.whiteSpace = "nowrap";
                toast.style.left = "50%";
                toast.style.transform = "translateX(-50%)";
                toast.style.backgroundColor = "#706060ff";
                toast.style.color = "#fcf7f2";
                toast.style.boxShadow = "0 1px 5px rgba(0,0,0,.15)";
                toast.style.padding = "10px 20px";
                toast.style.borderRadius = "5px";
                toast.style.zIndex = "10000";
                toast.style.fontSize = "14px";
                
                document.body.appendChild(toast);
            }
            toast.textContent = message;
            toast.style.display = "block";
            setTimeout(() => {
                toast.style.display = "none";
            }, 3000); // Hide after 3 seconds
        }
    }

    // Call WorkingHours inside initWorkingHours to initialize
    WorkingHours();
}




document.addEventListener("DOMContentLoaded", initAdminAppointments)


