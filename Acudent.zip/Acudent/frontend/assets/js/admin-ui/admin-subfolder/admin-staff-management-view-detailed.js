function showToastDentist(message) {
  let toast = document.getElementById('toast');

  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'toast-dentist';
    document.body.appendChild(toast);
  }

  toast.textContent = message;
  toast.style.opacity = '1';

  setTimeout(() => {
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

function EditBtnInfoStaff() {
  document.addEventListener('click', (e) => {
    // ✅ When Edit is clicked
    const editBtn = e.target.closest('.edit-btn-info-staff');
    if (editBtn) {
      const fields = document.querySelectorAll('.editable');
      const saveBtn = document.querySelector('.btn-save-staff-information');
      const cancelBtn = document.querySelector('.btn-cancel-staff-information');

      fields.forEach(f => f.disabled = false);
      editBtn.style.display = 'none';
      if (saveBtn) saveBtn.style.display = 'block';
      if (cancelBtn) cancelBtn.style.display = 'block';
      return;
    }

    // ✅ When Save is clicked
    const saveBtn = e.target.closest('.btn-save-staff-information');
    if (saveBtn) {
      const fields = document.querySelectorAll('.editable');
      const editBtn = document.querySelector('.edit-btn-info-staff');
      const cancelBtn = document.querySelector('.btn-cancel-staff-information');

      fields.forEach(f => f.disabled = true);
      if (saveBtn) saveBtn.style.display = 'none';
      if (cancelBtn) cancelBtn.style.display = 'none';
      if (editBtn) editBtn.style.display = 'block';

      showToastDentist('Changes saved successfully!');
      return;
    }

    // ✅ When Cancel is clicked (same as Save, but no toast)
    const cancelBtn = e.target.closest('.btn-cancel-staff-information');
    if (cancelBtn) {
      const fields = document.querySelectorAll('.editable');
      const editBtn = document.querySelector('.edit-btn-info-staff');
      const saveBtn = document.querySelector('.btn-save-staff-information');

      fields.forEach(f => f.disabled = true);
      if (saveBtn) saveBtn.style.display = 'none';
      if (cancelBtn) cancelBtn.style.display = 'none';
      if (editBtn) editBtn.style.display = 'block';
      return;
    }
  });

  const backButtons = document.querySelectorAll('.back-btn-patient-information');
  backButtons.forEach(btn => {
      btn.addEventListener('click', () => {
          const url = btn.getAttribute('data-page');
          if (!url) return;

          // Remove the param logic since dentistId is not needed
          if (typeof window.loadPage === 'function') {
              window.loadPage(url);
          } else {
              console.warn('⚠️ loadPage() function not found.');
          }
      });
  });
}

function initAdminStaffManagementViewDetailed() {
  const page = document.querySelector('.staff-information-record-view-main');
  if (!page) return;
  console.log('Patient Management Detailed initialized ✅');

  const saveBtn = document.querySelector('.btn-save-staff-information');
  const cancelBtn = document.querySelector('.btn-cancel-staff-information');
  if (saveBtn) saveBtn.style.display = 'none';
  if (cancelBtn) cancelBtn.style.display = 'none';

   EditBtnInfoStaff();
}

document.addEventListener('DOMContentLoaded', initAdminStaffManagementViewDetailed);
