function showToast(message) {
  let toast = document.getElementById('toast');

  if (!toast) {
    document.getElementById('toast');
    document.body.appendChild(toast);
  }

  toast.textContent = message;
  toast.style.opacity = '1';

  setTimeout(() => {
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}


function EditBtnInfo() {

  document.addEventListener('click', (e) => {
    // ✅ When Edit is clicked
    const editBtn = e.target.closest('.edit-btn');
    if (editBtn) {
      const fields = document.querySelectorAll('.editable');
      const saveBtn = document.querySelector('.btn-save');
      const cancelBtn = document.querySelector('.btn-cancel');

      fields.forEach(f => f.disabled = false);
      editBtn.style.display = 'none';
      if (saveBtn) saveBtn.style.display = 'block';
      if (cancelBtn) cancelBtn.style.display = 'block';
      return;
    }

    // ✅ When Save is clicked
    const saveBtn = e.target.closest('.btn-save');
    if (saveBtn) {
      const fields = document.querySelectorAll('.editable');
      const editBtn = document.querySelector('.edit-btn');
      const cancelBtn = document.querySelector('.btn-cancel');

      fields.forEach(f => f.disabled = true);
      if (saveBtn) saveBtn.style.display = 'none';
      if (cancelBtn) cancelBtn.style.display = 'none';
      if (editBtn) editBtn.style.display = 'block';

      showToast('Changes saved successfully!');
      return;
    }

    // ✅ When Cancel is clicked (same as Save, but no toast)
    const cancelBtn = e.target.closest('.btn-cancel');
    if (cancelBtn) {
      const fields = document.querySelectorAll('.editable');
      const editBtn = document.querySelector('.edit-btn');
      const saveBtn = document.querySelector('.btn-save');

      fields.forEach(f => f.disabled = true);
      if (saveBtn) saveBtn.style.display = 'none';
      if (cancelBtn) cancelBtn.style.display = 'none';
      if (editBtn) editBtn.style.display = 'block';
      return;
    }
  });

  const viewButtons = document.querySelectorAll('.back-btn-patient-information');
    viewButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const url = btn.getAttribute('data-page');
            if (!url) return;

            // Remove the param logic since dentistId is not needed
            if (typeof window.loadPage === 'function') {
                window.loadPage(url);
            } else {
                console.warn('⚠️ loadPage() function not found.');
            }
        });
    });

}


function initAdminPatientManagementViewDetailed() {
  const page = document.querySelector('#patient-information-record-view-main-id');
  if (!page) return;
  console.log('Patient Management Detailed initialized ✅');

  const saveBtn = document.querySelector('.btn-save');
  const cancelBtn = document.querySelector('.btn-cancel');
  if (saveBtn) saveBtn.style.display = 'none';
  if (cancelBtn) cancelBtn.style.display = 'none';

EditBtnInfo();
}

 document.addEventListener('DOMContentLoaded', initAdminPatientManagementViewDetailed);
