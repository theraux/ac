document.addEventListener("DOMContentLoaded", () => {
  // const backdrop = document.querySelector(".hero-banner-backdrop");
  // const overlay = document.querySelector(".hero-banner-overlay");

  // if (backdrop && overlay) {
  //   window.addEventListener("scroll", () => {
  //     if (window.scrollY > 50) {
  //       backdrop.classList.add("active");
  //       overlay.classList.add("dimmed");
  //     } else {
  //       backdrop.classList.remove("active");
  //       overlay.classList.remove("dimmed");
  //     }
  //   });
  // }

  initTestimonialSlider();
  faqFunction();
  section2Animation();
  section3Animation();
  section4Animation();
  section5Animation();
  section6Animation();
  section65Animation();
    section7Animation();
        section8Animation();





});

function section2Animation() {

  const section = document.querySelector('.section2');
  const earlyReveals = section.querySelectorAll('.reveal:not(.reveal-late)');
  const lateReveals = section.querySelectorAll('.reveal-late');

  const earlyObserver = new IntersectionObserver(entries => {
    if (entries[0].isIntersecting) {
      // Activate parent immediately
      earlyReveals.forEach(el => {
        if (!el.classList.contains('delay-1') && !el.classList.contains('delay-2')) {
          el.classList.add('active');
        }
      });
      // Stagger the delayed ones
      setTimeout(() => {
        earlyReveals.forEach(el => {
          if (el.classList.contains('delay-1')) el.classList.add('active');
        });
      }, 200);  // 0.2s delay
      setTimeout(() => {
        earlyReveals.forEach(el => {
          if (el.classList.contains('delay-2')) el.classList.add('active');
        });
      }, 200);  // 0.4s delay
      earlyObserver.unobserve(section);
    }
  }, { threshold: 0.2 });

  const lateObserver = new IntersectionObserver(entries => {
    if (entries[0].isIntersecting) {
      // Similar staggering for late reveals
      setTimeout(() => {
        lateReveals.forEach(el => {
          if (
            el.classList.contains('delay-3') ||
            el.classList.contains('delay-4')
          ) {
            el.classList.add('active');
          }

        });
      }, 200);

    }
  }, { threshold: 0.5 });

  earlyObserver.observe(section);
  lateObserver.observe(section);

}

function section3Animation() {
  const section = document.querySelector('.section3');
  const earlyReveals = section.querySelectorAll('.reveal:not(.reveal-late)');
  const lateReveals = section.querySelectorAll('.reveal-late');

  const earlyObserver = new IntersectionObserver(entries => {
    if (entries[0].isIntersecting) {
      earlyReveals.forEach(el => el.classList.add('active'));
      earlyObserver.unobserve(section);
    }
  }, { threshold: 0.2 });

  const lateObserver = new IntersectionObserver(entries => {
    if (entries[0].isIntersecting) {
      lateReveals.forEach(el => el.classList.add('active'));
      lateObserver.unobserve(section);
    }
  }, { threshold: 0.2 });

  earlyObserver.observe(section);
  lateObserver.observe(section);
}


function section4Animation() {
  const section = document.querySelector('.section4');
  const reveals = section.querySelectorAll('.reveal');

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.2;

      if (el.classList.contains('delay-1')) requiredRatio = 0.1;
      if (el.classList.contains('delay-2')) requiredRatio = 0.15;
      if (el.classList.contains('delay-3')) requiredRatio = 0.2;
      if (el.classList.contains('delay-4')) requiredRatio = 0.25;
      if (el.classList.contains('delay-5')) requiredRatio = 0.3;

      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.1, 0.2, 0.3, 0.4, 0.5]
  });

  reveals.forEach(el => observer.observe(el));
}



function section5Animation() {
  const section = document.querySelector('.section5');
  const reveals = section.querySelectorAll('.reveal');

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.2;

      if (el.classList.contains('reveal-header')) requiredRatio = 0.2;
      if (el.classList.contains('reveal-grid')) requiredRatio = 0.3;


      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.2, 0.3]
  });

  reveals.forEach(el => observer.observe(el));
}


function section6Animation() {
  const section = document.querySelector('.section6');
  const reveals = section.querySelectorAll('.reveal');

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.2;

      if (el.classList.contains('reveal-header')) requiredRatio = 0.2;
      if (el.classList.contains('reveal-content')) requiredRatio = 0.3;


      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.2, 0.3]
  });

  reveals.forEach(el => observer.observe(el));
}


function section65Animation() {
  const section = document.querySelector('.section-65');
  const reveals = section.querySelectorAll('.reveal');

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.2;

      if (el.classList.contains('reveal-left')) requiredRatio = 0.2;
      if (el.classList.contains('reveal-right')) requiredRatio = 0.2;


      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.2, 0.2]
  });

  reveals.forEach(el => observer.observe(el));
}


function section7Animation() {
  const section = document.querySelector('.section7');
  const reveals = section.querySelectorAll('.reveal');

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.2;

      if (el.classList.contains('reveal-left')) requiredRatio = 0.2;
      if (el.classList.contains('reveal-right')) requiredRatio = 0.2;


      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.2, 0.2]
  });

  reveals.forEach(el => observer.observe(el));
}



function section8Animation() {
  const section = document.querySelector('.section8');
  const reveals = section.querySelectorAll('.reveal');

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.2;

      if (el.classList.contains('reveal-header')) requiredRatio = 0.2;
      if (el.classList.contains('reveal-content')) requiredRatio = 0.1;


      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.2, 0.1]
  });

  reveals.forEach(el => observer.observe(el));
}





function faqFunction() {
  const faqItems = document.querySelectorAll('.faq-item');

  faqItems.forEach(item => {
    const question = item.querySelector('.faq-question');

    question.addEventListener('click', () => {
      // Close other items
      faqItems.forEach(otherItem => {
        if (otherItem !== item) {
          otherItem.classList.remove('active');
        }
      });

      // Toggle current item
      item.classList.toggle('active');
    });
  });
}


function initTestimonialSlider() {
  const wrapper = document.getElementById('testimonialWrapper');
  const pagination = document.getElementById('pagination');

  if (!wrapper || !pagination) return;

  // Original testimonials data
  const testimonials = [
    {
      img: 1,
      name: "Edward B.",
      text: "I've never felt more comfortable at a dentist's office. The staff is amazing!"
    },
    {
      img: 5,
      name: "Sarah M.",
      text: "Professional service and painless procedures. Highly recommend to everyone!"
    },
    {
      img: 8,
      name: "Michael T.",
      text: "Best dental experience I've ever had. The technology they use is top-notch."
    },
    {
      img: 9,
      name: "Jennifer L.",
      text: "The team made my dental anxiety disappear. I actually look forward to visits now!"
    },
    {
      img: 12,
      name: "David R.",
      text: "Excellent care and attention to detail. They truly care about their patients!"
    },
    {
      img: 16,
      name: "Lisa K.",
      text: "Modern facility with a warm, welcoming atmosphere. Five stars all around!"
    },
    {
      img: 16,
      name: "Lisa K.",
      text: "Modern facility with a warm, welcoming atmosphere. Five stars all around!"
    },
    {
      img: 16,
      name: "Lisa K.",
      text: "Modern facility with a warm, welcoming atmosphere. Five stars all around!"
    },
    {
      img: 16,
      name: "Lisa K.",
      text: "Modern facility with a warm, welcoming atmosphere. Five stars all around!"
    },
    {
      img: 16,
      name: "Lisa K.",
      text: "Modern facility with a warm, welcoming atmosphere. Five stars all around!"
    },
    {
      img: 16,
      name: "Lisa K.",
      text: "Modern facility with a warm, welcoming atmosphere. Five stars all around!"
    },
    {
      img: 16,
      name: "Lisa K.",
      text: "Modern facility with a warm, welcoming atmosphere. Five stars all around!"
    }

  ];

  const totalSlides = testimonials.length;
  const slidesPerView = 3;
  const cloneCount = slidesPerView;

  let currentIndex = cloneCount;
  let isDragging = false;
  let startPos = 0;
  let currentTranslate = 0;
  let prevTranslate = 0;
  let animationID = 0;

  // Calculate slides per view based on screen size
  function getSlidesPerView() {
    if (window.innerWidth < 768) return 1;
    return 3;
  }

  // Create slide HTML
  function createSlideHTML(testimonial) {
    return `
      <div class="testimonial-card-slide">
        <div class="testimonial-card">
          <div class="quote-icon">"</div>
          <div class="avatar">
            <img src="https://i.pravatar.cc/150?img=${testimonial.img}" alt="${testimonial.name}">
          </div>
          <h5>${testimonial.name}</h5>
          <span>Customer</span>
          <p>${testimonial.text}</p>
        </div>
      </div>
    `;
  }

  // Initialize slider with clones for seamless infinite loop
  function initSlider() {
    wrapper.innerHTML = '';

    // Add last few slides as clones at the beginning
    for (let i = totalSlides - cloneCount; i < totalSlides; i++) {
      wrapper.innerHTML += createSlideHTML(testimonials[i]);
    }

    // Add all real slides
    testimonials.forEach(testimonial => {
      wrapper.innerHTML += createSlideHTML(testimonial);
    });

    // Add first few slides as clones at the end
    for (let i = 0; i < cloneCount; i++) {
      wrapper.innerHTML += createSlideHTML(testimonials[i]);
    }

    // Set initial position without animation
    setTimeout(() => {
      wrapper.classList.add('no-transition');
      setPositionByIndex();
      setTimeout(() => wrapper.classList.remove('no-transition'), 50);
    }, 0);
  }

  // Create pagination dots (max 5)
  function createPagination() {
    pagination.innerHTML = '';
    const maxDots = Math.min(totalSlides, 5);

    for (let i = 0; i < maxDots; i++) {
      const dot = document.createElement('button');
      dot.classList.add('pagination-dot');
      if (i === 0) dot.classList.add('active');
      dot.addEventListener('click', () => goToSlide(i));
      pagination.appendChild(dot);
    }
  }

  // Update pagination active state
  function updatePagination() {
    const dots = document.querySelectorAll('.pagination-dot');
    const maxDots = Math.min(totalSlides, 5);

    // Get real index (accounting for clones)
    let realIndex = (currentIndex - cloneCount + totalSlides) % totalSlides;

    // Map to dot index
    let dotIndex = Math.round((realIndex / (totalSlides - 1)) * (maxDots - 1));
    dotIndex = Math.max(0, Math.min(dotIndex, maxDots - 1));

    dots.forEach((dot, index) => {
      dot.classList.toggle('active', index === dotIndex);
    });
  }

  // Go to specific slide from pagination
  function goToSlide(index) {
    currentIndex = cloneCount + index;
    setPositionByIndex();
    updatePagination();
  }

  // Set position by current index
  function setPositionByIndex() {
    const slideWidth = wrapper.querySelector('.testimonial-card-slide').offsetWidth;
    currentTranslate = currentIndex * -slideWidth;
    prevTranslate = currentTranslate;
    setSliderPosition();
  }

  // Set slider position
  function setSliderPosition() {
    wrapper.style.transform = `translateX(${currentTranslate}px)`;
  }

  // Handle infinite loop - jump to real slides when reaching clones
  function handleInfiniteLoop() {
    // If we're in the clones at the end, jump to the beginning (real slides)
    if (currentIndex >= cloneCount + totalSlides) {
      wrapper.classList.add('no-transition');
      currentIndex = cloneCount + (currentIndex - cloneCount - totalSlides);
      setPositionByIndex();
      setTimeout(() => wrapper.classList.remove('no-transition'), 50);
    }
    // If we're in the clones at the beginning, jump to the end (real slides)
    else if (currentIndex < cloneCount) {
      wrapper.classList.add('no-transition');
      currentIndex = cloneCount + totalSlides + (currentIndex - cloneCount);
      setPositionByIndex();
      setTimeout(() => wrapper.classList.remove('no-transition'), 50);
    }
  }

  // Snap to nearest slide
  function snapToNearest() {
    const slideWidth = wrapper.querySelector('.testimonial-card-slide').offsetWidth;

    // Calculate nearest index
    currentIndex = Math.round(-currentTranslate / slideWidth);

    setPositionByIndex();
    updatePagination();

    // After snap animation completes, check if we need to loop
    setTimeout(() => {
      handleInfiniteLoop();
      updatePagination();
    }, 450);
  }

  // Touch/Mouse start
  function touchStart(event) {
    isDragging = true;
    startPos = getPositionX(event);
    animationID = requestAnimationFrame(animation);
    wrapper.classList.add('no-transition');
  }

  // Touch/Mouse move
  function touchMove(event) {
    if (isDragging) {
      const currentPosition = getPositionX(event);
      currentTranslate = prevTranslate + currentPosition - startPos;
    }
  }

  // Touch/Mouse end
  function touchEnd() {
    isDragging = false;
    cancelAnimationFrame(animationID);
    wrapper.classList.remove('no-transition');
    snapToNearest();
  }

  // Get position X from event
  function getPositionX(event) {
    return event.type.includes('mouse') ? event.pageX : event.touches[0].clientX;
  }

  // Animation loop for smooth dragging
  function animation() {
    setSliderPosition();
    if (isDragging) requestAnimationFrame(animation);
  }

  // Add event listeners
  function addEventListeners() {
    wrapper.addEventListener('mousedown', touchStart);
    wrapper.addEventListener('mouseup', touchEnd);
    wrapper.addEventListener('mouseleave', touchEnd);
    wrapper.addEventListener('mousemove', touchMove);

    wrapper.addEventListener('touchstart', touchStart, { passive: true });
    wrapper.addEventListener('touchend', touchEnd);
    wrapper.addEventListener('touchmove', touchMove, { passive: true });

    wrapper.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  // Handle window resize
  let resizeTimer;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      const realIndex = (currentIndex - cloneCount + totalSlides) % totalSlides;
      initSlider();
      currentIndex = cloneCount + realIndex;
      setPositionByIndex();
      updatePagination();
    }, 250);
  });

  // Initialize everything
  initSlider();
  createPagination();
  addEventListeners();
}



